USE libreria;

INSERT INTO Libro VALUES ('978-84-376-0494-7', 'El Quijote', 'Miguel de Cervantes','Novela', 'Anaya', 20.00);
INSERT INTO Libro VALUES ('978-84-376-0494-8', 'JavaScript: The Good Parts', 'Douglas Crockford','Aprendizaje', 'Yahoo Press', 14.09);

INSERT INTO Cliente VALUES('12345678A', 'Juan', 'García', 'Calle Mayor 1', '123456789');

INSERT INTO Empleado VALUES('87654321B', 'Pedro', 'González', 'Calle Menor 2', '987654321');

INSERT INTO Venta VALUES( '2021-06-01', '12345678A', '978-84-376-0494-7');

INSERT INTO Prestamo VALUES( '2021-06-01', '12345678A', '978-84-376-0494-8');